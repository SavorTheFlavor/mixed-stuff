package com.me.sso.controller;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.me.sso.bean.User;
import com.me.sso.service.UserAccountService;
import com.me.sso.util.KeyGenerator;
import com.me.sso.util.TokenUserData;
import com.sun.xml.internal.ws.util.StringUtils;

/**
 * Servlet implementation class UserLoginServlet
 */
@WebServlet("/login")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private UserAccountService userAccountService = new UserAccountService();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 *�����get�������������ص�¼ҳ
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String origUrl = request.getParameter("origUrl");
		request.setAttribute("origUrl",origUrl);
		
		request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String account = request.getParameter("account");
		String passwd = request.getParameter("passwd");
		String origUrl = request.getParameter("origUrl");

		User user = null;
		try{
			user = userAccountService.findUserByAccount(account);
			
			if(user !=null){
				if(user.getPasswd().equals(passwd)){
					
					//����token
					String token = KeyGenerator.generate();
					//���浽ȫ��Ψһ�����ݽṹ��java��̬��
					TokenUserData.addToken(token, user);
					
					//дcookie
					Cookie tokenCookie = new Cookie("token", token);
					tokenCookie.setPath("/");
					//tokenCookie.setDomain(domain);
					tokenCookie.setHttpOnly(true);
					response.addCookie(tokenCookie);
					
					if(origUrl == null || origUrl.equals("")){
						origUrl="login_success";
					}else{
						origUrl = URLDecoder.decode(origUrl);
					}
					response.sendRedirect(origUrl);
				}else{
					backToLoginPage(request, response, account, origUrl, "password error");
				}//�������
				
			}else{
				backToLoginPage(request, response, account, origUrl, "user does not exist!");
			}//�û�������
			
		}catch(Exception e){
			e.printStackTrace();
			backToLoginPage(request, response, account, origUrl, "ϵͳ����");
		}
		
	}
	
	private void backToLoginPage(HttpServletRequest request, HttpServletResponse response,String account,String origUrl, String errinfo) throws ServletException, IOException{
		request.setAttribute("account", account);
		request.setAttribute("origUrl", origUrl);
		request.setAttribute("errinfo", errinfo);
		
		request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);
	}

}
