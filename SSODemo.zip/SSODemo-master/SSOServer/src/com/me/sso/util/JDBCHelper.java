package com.me.sso.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class JDBCHelper {
	
	public static final String URL="jdbc:mysql://127.0.0.1:3306/user_info";
	public static final String USER="root";
	public static final String PASSWORD="23456";
	
	private static Connection conn;
	
	static{
		try {
			//������������
			Class.forName("com.mysql.jdbc.Driver");
			//������ݿ�����
			conn =	DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static Connection getConnection(){
		return conn;
	}
	
	public static void main(String[] args) throws Exception {


		
	}
}
