package com.me.sso.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CookieUtil {

	public static String getToken(HttpServletRequest request, String thing) {
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals(thing)){
				return cookie.getValue();
			}
		}
		return null;
	}

	public static void removeCookie(HttpServletResponse response, String token, String path, String domain) {
		//��дcookie��ʹ�����
		Cookie cookie = new Cookie(token, null);
		cookie.setMaxAge(-1000);
		if(path != null){
			cookie.setPath(path);
		}
		if(domain != null){
			cookie.setDomain(domain);
		}
		response.addCookie(cookie);
	}

}
