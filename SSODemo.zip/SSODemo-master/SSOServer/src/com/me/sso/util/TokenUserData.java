package com.me.sso.util;

import java.util.HashMap;
import java.util.Map;

import com.me.sso.bean.User;

public class TokenUserData {
	
	private static Map<String, User> data = new HashMap<>();
	
	
	private TokenUserData(){
		
	}
	
	public static void addToken(String token, User user){
		data.put(token, user);
	}
	
	public static User validateToken(String token){
		return data.get(token);
	}
	
	public static void removeToken(String token){
		data.remove(token);
	}
}
