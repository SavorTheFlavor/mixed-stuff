package com.me.sso.service;

import java.sql.SQLException;

import com.me.sso.bean.User;
import com.me.sso.dao.UserDao;

public class UserAccountService {
	
	private UserDao userDao = new UserDao();

	public User findUserByAccount(String account) {
		try {
			return userDao.queryUserByAccount(account);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
