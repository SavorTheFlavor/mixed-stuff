package com.me.sso.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.me.sso.bean.User;
import com.me.sso.util.JDBCHelper;

public class UserDao {
	
	private Connection conn = JDBCHelper.getConnection();

	public User queryUserByAccount(String account) throws SQLException {
		
		User user = new User();
		String sql = "select * from user where account = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, account);
		
		ResultSet resultSet = ps.executeQuery();
		if(!resultSet.next()){//û�鵽��nextΪfalse
			return null;
		}
		user.setId(resultSet.getInt("id"));
		user.setName(resultSet.getString("name"));
		user.setAccount(account);
		user.setPasswd(resultSet.getString("passwd"));
		return user;
	}

}
