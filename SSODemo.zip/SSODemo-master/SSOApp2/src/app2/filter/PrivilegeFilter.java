package app2.filter;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.me.sso.client.bean.User;

public class PrivilegeFilter implements Filter{

	private static final String SSO_LOGIN_URL = "http://localhost:8080/server/login";
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
//		HttpServletRequest req = (HttpServletRequest)request;
//		HttpServletResponse resp = (HttpServletResponse)response;
//		
//		String origUrl = req.getRequestURL().toString();//����·��
//		String queryStr = req.getQueryString();//�������
//		if(queryStr != null){
//			origUrl += "?" + queryStr;
//		}
//		
//		User user = (User)req.getSession().getAttribute("user");
//		if(user == null){
//			resp.sendRedirect(SSO_LOGIN_URL+"?origUrl="+
//	URLEncoder.encode(origUrl,"utf-8"));
//			return;
//		}
//		String account = user.getAccount();
//		System.out.println(account);
//		if(account != "princess"){
//			response.getWriter().write("Permission denied!");
//		}else {
//			chain.doFilter(req, resp);
//		}
		chain.doFilter(request, response);

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
