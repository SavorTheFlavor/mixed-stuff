package com.me.sso.client.filter;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.me.sso.client.bean.User;
import com.me.sso.client.util.CookieUtil;


public class SSOFilter implements Filter{
	
	private static final String SSO_LOGIN_URL = "http://localhost:8080/server/login";
	private static final String SSO_VALIDATE_URL = "http://localhost:8080/server/validate";

	
	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest)arg0;
		HttpServletResponse resp = (HttpServletResponse)arg1;
		
		req.getSession();//Ϊ�������쳣 'Cannot create a session after the response has been committed
		
		String token = CookieUtil.getToken(req, "token");
		
		String origUrl = req.getRequestURL().toString();//����·��
		String queryStr = req.getQueryString();//�������
		
		if(queryStr != null){
			origUrl += "?" + queryStr;
		}
		
		if(token == null || token.trim().equals("")){//token��Ч
			resp.sendRedirect(SSO_LOGIN_URL+"?origUrl="+
		URLEncoder.encode(origUrl,"utf-8"));//����ԭ�ȵ�����·��
			//return;
		}else{
			URL validateUrl = new URL(SSO_VALIDATE_URL+"?token="+token);
			HttpURLConnection connection = (HttpURLConnection) validateUrl.openConnection();
			connection.connect();
			InputStream is = connection.getInputStream();
			
			byte[] buf = new byte[is.available()];
			is.read(buf);
			
			String res = new String(buf,0,buf.length);
			if(res.length() == 0){//У��ʧ��
				resp.sendRedirect(SSO_LOGIN_URL+"?origUrl="+
		URLEncoder.encode(origUrl,"utf-8"));
			}else{
				User user = new User();
				String[] tmp = res.split(";");
				//��ȡ�û���Ϣ
				for(int i = 0; i < tmp.length ; i++){
					String[] attr = tmp[i].split("=");
					switch (attr[0]) {
					case "id":
						user.setId(Integer.parseInt(attr[1]));
						break;
					case "name":
						user.setName(attr[1]);
						break;
					case "account":
						user.setAccount(attr[1]);
						break;
					default:
						break;
					}
				}
				System.out.println(user);
				req.setAttribute("user", user);
				req.getSession().setAttribute("user", user);
			}
		}
		chain.doFilter(req, resp);	
	}
	
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
