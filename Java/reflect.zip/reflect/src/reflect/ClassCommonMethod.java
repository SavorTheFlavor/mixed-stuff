package reflect;

import java.awt.Color;
import java.io.File;
import java.io.Serializable;
import java.lang.reflect.Modifier;
import java.util.Calendar;
import java.util.Random;
import java.util.Scanner;

@Deprecated//��ʾ��ʱ
class Hah implements Serializable,Comparable<Hah>{
	public class Hahaha{
		
	}
	private class Hahah{
		
	}
	@Override
	public int compareTo(Hah o) {
		return 0;
	}
}

public class ClassCommonMethod {
	public static void main(String[] args) {
		//��ȡHaha���͵���Ϣ
		
		Class<Hah> hah = Hah.class;
		
		Class<?>[] innerClasses = hah.getClasses();//��ȡpublic�ĵ��ڲ���
		for(Class<?> cls: innerClasses){
			System.out.println(cls);
		}
		
		Class<?>[] innerClasses2 = hah.getDeclaredClasses();//��ȡ�ڲ��࣬��������
		
		Class<?>[] intf = hah.getInterfaces();//��ȡ����ʵ�ֵĽӿ�
		
		Class<Color> c = Color.class;
		
		System.out.println(hah.getClasses()[0].getModifiers());//1
		System.out.println(Modifier.toString(hah.getModifiers()));
		System.out.println(Modifier.toString(c.getModifiers()));
		
		//getName getȫ�޶���
		//getSimpleName
		System.out.println(c.getSimpleName());
		
		System.out.println(c.getSuperclass());
		
		System.out.println(String.class.isAnnotation());//�Ƿ���ע��
		System.out.println(String.class.isArray());
		System.out.println(String.class.isInstance(c));
		System.out.println(String.class.isPrimitive());//�Ƿ������������
		
		System.out.println(Deprecated.class.isAnnotation());//true��ע��Ҳ����
		
		Object obj = new Random();
		Class<Random> r = (Class<Random>) obj.getClass().asSubclass(Random.class);//��ȡָ��������
		System.out.println();
	}
}
