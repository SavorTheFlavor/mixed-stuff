package reflect;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

public class InvokeMethodDemo2 {
	public static void main(String[] args) throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		
		Class<Arrays> cls = Arrays.class;
		
		Method m =cls.getMethod("asList", Object[].class);
		
		System.out.println(m.invoke(null, new Object[]{new String[]{"haha","heihei"}}));
		
	}
}
