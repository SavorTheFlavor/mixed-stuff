package reflect;

import java.lang.reflect.Field;

public class FieldDemo {
	public static void main(String[] args) throws Exception{
		
		Class<Miku2> cls = Miku2.class;
		
		Miku2 mk = cls.newInstance();
		
		Field f = cls.getDeclaredField("loverTendancy");
		f.setAccessible(true);
		f.set(mk, "Lovely");
		//get��ʱ����getInt֮��ıȽϺã�����ǿת
		System.out.println(f.get(mk));
		
	}

}
