package reflect;

public class CrossDressingDemo implements CrossDressing {
	private String name;
	private String sex;
	public CrossDressingDemo(){//�޲ι���
		
	}
	public CrossDressingDemo(String name, String sex) {
		this.name = name;
		this.sex = sex;
	}
	

	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void shapeShift() {
		System.out.println("I became a girl with dajiji haning in my skirt!");
	}
	
	public void isAttractive() {
		System.out.println("I'm a girl with dajiji haning in my skirt!");
		
	}
	
	
}
