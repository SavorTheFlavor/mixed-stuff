package reflect;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
import java.util.Random;

public class NewInstanceByConfigFile {
	private static Properties p;
	private static String name = "obj.properties";
	//��̬�����
	static{
		p = new Properties();
		InputStream inStream =//��ȡ�������
												//	�������ķ�ʽ��ȡԴ�ļ�
				Thread.currentThread().getContextClassLoader().getResourceAsStream(name);
		
		try {
			p.load(inStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
//	public static Object getBean(String className) throws ClassNotFoundException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException{
//		Class<?> cls = Class.forName(className);
//		return cls.getConstructor(String.class).newInstance("haha");
//	}
	//����
	public static<T> T getBean(String className) throws ClassNotFoundException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException{
		Class<T> cls = (Class<T>) Class.forName(className);
		return cls.newInstance();
	}
	
	public static String getValue(String key){
		return p.getProperty(key);
	}
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, SecurityException, InvocationTargetException, NoSuchMethodException {
		String className = getValue("string");//String��
		
		Class<?> cls = Class.forName(className);
		
		System.out.println(cls.newInstance());
//		Object obj = getBean("string");
//		String str = (String)obj;
//		System.out.println(str.trim());
		
		//ʹ�÷���
		System.out.println("-----------------------------");
		System.out.println(getBean(getValue("random")));
	}
}
