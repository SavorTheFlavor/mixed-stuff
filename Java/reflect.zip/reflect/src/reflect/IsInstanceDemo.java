package reflect;

import java.awt.Color;

public class IsInstanceDemo {
	public static void main(String[] args) {
		Color c = new Color(1283421);
		Class<Color> cls = (Class<Color>) c.getClass();
		
		System.out.println(c instanceof Color);//true
		
		System.out.println(Color.class.isInstance(c));//true//Color cc = c;
		System.out.println(Object.class.isInstance(c));//true//Object cc = c;
		
	}
}
