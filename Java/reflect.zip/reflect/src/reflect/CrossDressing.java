package reflect;

public interface CrossDressing {
	
	public  String appearance="lovely" ;
	public String sexPrefer ="normal";
	
	public void shapeShift();
	public void isAttractive();
	
}
