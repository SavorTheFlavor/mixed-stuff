package generic.DAO;

import generic.domain.Emp;

public interface IEmpDAO extends IGenericDAO<Emp> {

}
