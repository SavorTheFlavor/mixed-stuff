package generic.DAO;

import generic.domain.Dept;

public interface IDeptDAO extends IGenericDAO<Dept> {
	
}
