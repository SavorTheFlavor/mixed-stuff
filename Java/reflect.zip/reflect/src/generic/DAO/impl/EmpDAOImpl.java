package generic.DAO.impl;

import generic.DAO.IEmpDAO;
import generic.domain.Emp;


public class EmpDAOImpl extends GenericDAOImpl<Emp> implements IEmpDAO {

}
