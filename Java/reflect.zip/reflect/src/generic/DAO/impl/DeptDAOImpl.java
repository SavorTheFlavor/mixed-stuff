package generic.DAO.impl;



import generic.DAO.IDeptDAO;
import generic.domain.Dept;

public class DeptDAOImpl extends GenericDAOImpl<Dept> implements IDeptDAO {
	public DeptDAOImpl(){
		super();
	}


}
