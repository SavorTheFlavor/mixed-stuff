package generic.DAO;

import java.io.Serializable;
import java.util.List;

public interface IGenericDAO<T> {
	void add(T newObj);
	Long remove(Serializable id);
	void update(Serializable id, T newObj);
	T get(Serializable id);
	List<T> getAll();

}
