package generic;

import generic.DAO.IDeptDAO;
import generic.DAO.IEmpDAO;
import generic.DAO.impl.DeptDAOImpl;
import generic.DAO.impl.EmpDAOImpl;
import generic.domain.Dept;
import generic.domain.Emp;

public class Test {
	public static void main(String[] args) {
		IDeptDAO deptDAO = new DeptDAOImpl();
		
		Dept dept = deptDAO.get(128738);
		System.out.println(dept);
		
		IEmpDAO empDAO = new EmpDAOImpl();
		Emp emp = empDAO.get(12873);
		System.out.println(emp);
		
	}
}
