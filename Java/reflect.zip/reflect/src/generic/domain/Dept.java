package generic.domain;

public class Dept {

}
