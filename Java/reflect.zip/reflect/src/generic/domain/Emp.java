package generic.domain;

public class Emp {

}
