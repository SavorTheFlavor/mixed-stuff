package com.me.nio;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class NIOServer {
	
	private int blocksize = 4096;
	private ByteBuffer receivebuf = ByteBuffer.allocate(blocksize);
	private ByteBuffer sendbuf = ByteBuffer.allocate(blocksize);
	private Selector selector;
	private String ip;
	private int port;
	private int clientNum = 0;
	private Random random = new Random();
	
	public NIOServer(int port) throws IOException {
		this("127.0.0.1",  port);
	}
	
	public NIOServer(String ip, int port) throws IOException {
		this.ip = ip;
		this.port = port;
		ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
		serverSocketChannel.bind(new InetSocketAddress(ip, port));
		serverSocketChannel.configureBlocking(false);
		this.selector = Selector.open();
		serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
	}
	
	public void listen() throws IOException {
		System.err.println("Server listening at ===>>> "+ip+":"+port);
		while(true) {
			selector.select(); //blocking..
			Set<SelectionKey> selectedKeys = selector.selectedKeys();
			Iterator<SelectionKey> iterator = selectedKeys.iterator();
			while (iterator.hasNext()) {
				SelectionKey selectionKey = iterator.next();
				handleKey(selectionKey);
			}
			selectedKeys.clear();
			try {
				Thread.sleep(random.nextInt(2500));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void handleKey(SelectionKey selectionKey) throws IOException {
		ServerSocketChannel server;
		SocketChannel client;
		if(selectionKey.isAcceptable()) {
			server = (ServerSocketChannel)selectionKey.channel(); //Returns the channel for which this key was created
			client = server.accept();
			this.clientNum++;
			client.configureBlocking(false);
			client.register(selector, SelectionKey.OP_READ);  // for the greeting message from client
		}else if(selectionKey.isReadable()){
			client = (SocketChannel)selectionKey.channel();
			receivebuf.clear();
			int len = client.read(receivebuf);
			if(len > 0) {
				String msg = new String(receivebuf.array(), 0, len);
				System.err.println(new Date() + " ===>> received a message from client:"+msg);
			}
			client.register(selector, SelectionKey.OP_WRITE);
		}else if(selectionKey.isWritable()){
			client = (SocketChannel)selectionKey.channel();
			sendbuf.clear();
			String sendtxt = "What's up??";
			sendbuf.put(sendtxt.getBytes());
			sendbuf.flip();
			client.write(sendbuf);
			client.register(selector, SelectionKey.OP_READ);
		}
	}
	
	public static void main(String[] args) throws IOException {
		NIOServer server = new NIOServer(7321);
		server.listen();
	}

}
