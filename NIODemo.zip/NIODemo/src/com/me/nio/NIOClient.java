package com.me.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class NIOClient {
	private int blocksize = 4096;
	private ByteBuffer receivebuf = ByteBuffer.allocate(blocksize);
	private ByteBuffer sendbuf = ByteBuffer.allocate(blocksize);
	private Selector selector;
	private String ip;
	private int port;
	private Random random = new Random();
	

	public NIOClient(String ip, int port) {
		this.ip = ip;
		this.port = port;
	}

	public void start() throws IOException {
		this.selector = Selector.open();
		SocketChannel client = SocketChannel.open();
		client.configureBlocking(false);
		client.register(selector, SelectionKey.OP_CONNECT);
		client.connect(new InetSocketAddress(ip, port));
		
		while(true) {
			selector.select();
			Set<SelectionKey> selectedKeys = selector.selectedKeys();
			Iterator<SelectionKey> iterator = selectedKeys.iterator();
			while (iterator.hasNext()) {
				SelectionKey selectionKey = iterator.next();
				if(selectionKey.isConnectable()) {
					client = (SocketChannel)selectionKey.channel();
					if(client.isConnectionPending()) {
						client.finishConnect();
						sendbuf.clear();
						sendbuf.put("Hey! Server......".getBytes());
						sendbuf.flip();
						client.write(sendbuf);
						System.err.println("pending.............................................................");
					}
					client.register(selector, SelectionKey.OP_READ);
				}else if(selectionKey.isReadable()){
					client = (SocketChannel)selectionKey.channel();
					receivebuf.clear();
					int len = client.read(receivebuf);
					if(len > 0) {
						String receivetxt = new String(receivebuf.array(), 0, len);
						System.out.println(new Date()+" message from server:"+receivetxt);
					}
					client.register(selector, SelectionKey.OP_WRITE);
				}else if(selectionKey.isWritable()) {
					client = (SocketChannel)selectionKey.channel();
					sendbuf.clear();
					sendbuf.put("!!!!!!!!!!!!!..".getBytes());
					sendbuf.flip();
					client.write(sendbuf);
					client.register(selector, SelectionKey.OP_READ);
				}
			}
			selectedKeys.clear();
			try {
				Thread.sleep(random.nextInt(2500));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	private void handleKey(SelectionKey selectionKey) throws IOException {
		ServerSocketChannel server;
		SocketChannel client;
		if(selectionKey.isAcceptable()) {
			server = (ServerSocketChannel)selectionKey.channel(); //Returns the channel for which this key was created
			client = server.accept();
			client.configureBlocking(false);
			client.register(selector, SelectionKey.OP_READ);
		}else if(selectionKey.isReadable()){
			client = (SocketChannel)selectionKey.channel();
			int len = client.read(receivebuf);
			if(len > 0) {
				String msg = new String(receivebuf.array(), 0, len);
				System.err.println("received a message from client:"+msg);
			}
			client.register(selector, SelectionKey.OP_WRITE);
		}else if(selectionKey.isWritable()){
			client = (SocketChannel)selectionKey.channel();
			sendbuf.clear();
			String sendtxt = "Hey!!!";
			sendbuf.put(sendtxt.getBytes());
			sendbuf.flip();
			client.write(sendbuf);
		}
	}
	
	public static void main(String[] args) throws IOException {
		new NIOClient("127.0.0.1", 7321).start();;
	}
	
}
