package com.me.repository;

import com.me.domain.Employee;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * Created by Administrator on 2017/10/9.
 */
public interface EmployeePagingAndSortingRepository extends PagingAndSortingRepository<Employee,Integer> {
}
