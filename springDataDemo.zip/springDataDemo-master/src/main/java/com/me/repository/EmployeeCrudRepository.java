package com.me.repository;

import com.me.domain.Employee;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Administrator on 2017/10/9.
 */
public interface EmployeeCrudRepository extends CrudRepository<Employee, Integer>{
}
