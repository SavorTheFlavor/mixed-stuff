package com.me.repository;

import com.me.domain.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by Administrator on 2017/10/1.
 */
//@RepositoryDefinition(domainClass = Employee.class,idClass = Integer.class)
public interface EmployeeRepository extends JpaRepository<Employee, Integer>, JpaSpecificationExecutor<Employee> {
    Employee findByName(String name);
    //where name like ?% and age < ?
    List<Employee> findByNameStartingWithAndAgeLessThan(String name, Integer age);
    List<Employee> findByNameEndingWithAndAgeLessThan(String name, Integer age);

    // where name in (?,?.....) or age < ?
    List<Employee> findByNameInOrAgeLessThan(List<String> names, Integer age);

    @SuppressWarnings("JpaQlInspection")
    //默认hql , 用sql要加native属性
    @Query("select e2 from Employee e2 where id = (select max(id) from Employee e1)")
    Employee getEmployeeByMaxId();

    //通过占位符
    @SuppressWarnings("JpaQlInspection")
    @Query("select e from Employee e where name = ?1 and age = ?2")
    List<Employee> queryByParams1(String name, Integer age);

    //通过注解指定参数名
    @SuppressWarnings("JpaQlInspection")
    @Query("select e from Employee e where name = :name and age = :age")
    List<Employee> queryByParams2(@Param("name") String name, @Param("age") Integer age);

    //原生query
    @SuppressWarnings("JpaQlInspection")
    @Query(nativeQuery = true,value = "select count(1) from employee") //count(1)对第一列计数
    Long getTotal();

    //更新操作需要加上@Modifying
    @SuppressWarnings("JpaQlInspection")
    @Modifying
    @Query("update Employee e set e.age=:age where e.id = :id")
    int update(@Param("id") Integer id, @Param("age") Integer age);
}
