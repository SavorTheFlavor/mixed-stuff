package com.me;

import com.me.dao.StudentDAO;
import com.me.domain.Employee;
import com.me.domain.Student;
import com.me.repository.EmployeeRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.persistence.criteria.*;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/10/1.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:beans-new.xml"})
public class SpringDataTest {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void testFindByName(){
        employeeRepository.update(1,2222);
        System.out.print(employeeRepository.findByName("rr"));
    }
    @Test
    public void testFindByNameStartWithAndAgeLessThan(){
        List<Employee> employees = employeeRepository.findByNameStartingWithAndAgeLessThan("asd", 22);
        for (Employee e: employees) {
            System.out.println(e);
        }
    }

    @Test
    public void findByNameInOrAgeLessThan(){
        List names = new ArrayList();
        names.add("rr");
        names.add("frenzy");
        List<Employee> employees = employeeRepository.findByNameInOrAgeLessThan(names, 12);
        for (Employee e: employees) {
            System.out.println(e);
        }
    }

    @Test
    public void getEmployeeByMaxId(){
        System.out.print(employeeRepository.getEmployeeByMaxId());
    }

    @Test
    public void queryByParams(){
        List<Employee> employees = employeeRepository.queryByParams2("brace", 22);
        for (Employee e: employees) {
            System.out.println(e);
        }
    }

    @Test
    public void getTotal(){
        System.out.print(employeeRepository.getTotal());
    }

    @Test
    public void testPageAndSort(){

        Sort.Order order = new Sort.Order(Sort.Direction.DESC,"age");
        Sort sort = new Sort(order);

        Pageable pageable = new PageRequest(6,7,sort);
        Page<Employee> pageInfo = employeeRepository.findAll(pageable);
        System.out.println("总页数："+pageInfo.getTotalPages());
        System.out.println("总记录数："+pageInfo.getTotalElements());
        System.out.println(pageInfo.getContent());
    }

    /**
     *  root: /employee/age
     *  query: 添加查询条件
     *  cb: build Predicate
     */
    @Test
    public void testJpaSpecificationExecutor(){//criteria
        Specification<Employee> specification = new Specification<Employee>() {
            @Override
            public Predicate toPredicate(Root<Employee> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                Path path = root.get("age");
                return cb.gt(path,33);//greater than
            }
        };

        Sort.Order order = new Sort.Order(Sort.Direction.DESC,"age");
        Sort sort = new Sort(order);

        Pageable pageable = new PageRequest(3,7,sort);
        Page<Employee> pageInfo = employeeRepository.findAll(specification,pageable);
        System.out.println("总页数："+pageInfo.getTotalPages());
        System.out.println("总记录数："+pageInfo.getTotalElements());
        System.out.println(pageInfo.getContent());
    }


}
