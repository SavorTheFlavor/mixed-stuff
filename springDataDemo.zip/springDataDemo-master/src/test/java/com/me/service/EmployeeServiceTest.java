package com.me.service;

import com.me.domain.Employee;
import com.me.repository.EmployeeRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/10/8.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:beans-new.xml"})
public class EmployeeServiceTest {

    @Autowired
    private EmployeeService employeeService;

    @Test
    public void updateTest(){
        employeeService.update(1,3333);
    }

    @Test
    public void saveTest(){
        List<Employee> employees = new ArrayList<>();
        for (int i=0;i<100;i++){
            employees.add(new Employee("monster"+i,i));
        }
        employeeService.save(employees);
    }

}
